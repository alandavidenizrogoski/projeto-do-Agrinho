// definindo variaveis globais
let jardineiro;
let plantas = [];
let temperatura = 10;
let totalarvores = 0;

function setup() {
  createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2, height - 50);
}

function draw() {
  //usando map() para ajustar a cor de fundo de forma mais controlada
  let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208),
                            map(totalarvores, 0, 100, 0, 1));
  background(corFundo);
  
  mostrarinformacoes();
  
  temperatura += 0.1;
  
  jardineiro.atualizar();
  jardineiro.mostrar();
  
  //verifica se o jogo acabou
  verificarfimdejogo();
  
  //usando map() para aplicar o comportamento de arvores plantadas
  plantas.map((arvore) => arvore.mostrar());
}
  //funcao para mostrar as informacoes na tela
  function mostrarinformacoes(){
    textSize(26);
    fill(0);
    text("vamos plantar arvores para reduzir a temperatura?", 10, 30)
    textSize(14);
    fill('white');
    text("temperatura: " + temperatura.toFixed(2),10, 390);
    text("arvores plantadas: " + totalarvores, 460,390);
    text("para movimentar o personagem use as setas do teclado", 10, 60);
    text("para plantar arvores use P ou espaço", 10, 80);
  }
  //funcao para verificar se o jogo acabou
  function verificarfimdejogo() {
    if (totalarvores > temperatura) {
      mostrarmensagemdevitoria();
    } else if (temperatura > 50) {
      mostrarmensagemdederrota();
    }
}
//funcao para mostrar mensagem de vitoria aqui 
function verificarfimdejogo(){
  if (totalarvores > temperatura) {
    mostrarmensagemdevitoria();
  } else if (temperatura > 50) {
    mostrarmensagemdederrota();
  }
}
//funcao para mostrar mensagem de vitoria
function mostrarmensagemdevitoria() {
  textSize(20);
  fill(0,0,0);
  text("Voce venceu, voce plantou muitas arvores", 100,200);
  noLoop();
}

//funcao para mostrar mensagem de derrota
function mostrarmensagemdederrota(){
  textSize(20);
  fill(0,0,0);
  text("voce perdeu a temperatura esta muito alta", 100, 200);
  noLoop();
}
//clase que cria o jardineiro
class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '🧑🏿‍🌾'
    this.velocidade = 3;
  }
    
    //funcao para atuzalizar a posicao do jardineiro atualizar() {
  atualizar(){
      if (keyIsDown(LEFT_ARROW)) {
        this.x -= this.velocidade;
      }
      if (keyIsDown(RIGHT_ARROW)) {
        this.x += this.velocidade;
      }
      if (keyIsDown(UP_ARROW)) {
        this.y -= this.velocidade;
      }
      if (keyIsDown(DOWN_ARROW)) {
        this.y += this.velocidade;
      }
    }
  
    //FUNCAO PARA DESENHAR O JARDINEIRO NA TELA
  mostrar(){
    textSize(32);
    text(this.emoji, this.x, this.y);
  }
}

// Classe para as árvores
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '🌳';
  }
    
  mostrar() {
    textSize(32);
    text(this.emoji, this.x, this.y);
  }
}
  
    //funcao para plantar uma arvore
    function keyPressed() {
      if (key === ' ' || key === 'p') {
        let arvore = new Arvore(jardineiro.x, jardineiro.y);
        plantas.push(arvore);
        totalarvores++;
        temperatura -= 3;
        if (temperatura <0) temperatura = 0;
  }
}
